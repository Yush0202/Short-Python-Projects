import cv2
import numpy as np
from PIL import ImageGrab

def screenrecorder():
    screen_width = 1366
    screen_height = 768
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter("C:/Users/KIIT/Desktop/Python tut/screen recorder/screen recordings/output.avi", fourcc, 5.0, (screen_width, screen_height))  # Output video file

    while True:
        img = ImageGrab.grab(bbox=(0, 0, screen_width, screen_height))  # Capture the screen
        img_np = np.array(img.convert('RGB'))  # Ensure the image is in RGB format
        frame = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)  # Convert RGB to BGR

        cv2.imshow("Screen Recorder", frame)
        out.write(frame)

        if cv2.waitKey(1) == 27:  # Press 'Esc' to exit
            break
    
    out.release()
    cv2.destroyAllWindows()
    print("Screen recording saved as output.avi")

screenrecorder()
