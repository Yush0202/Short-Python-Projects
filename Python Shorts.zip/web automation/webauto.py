import webbrowser as wb

def webauto():
    
    chrome_path = "C:/Program Files/Google/Chrome/Application/chrome.exe %s"
    
    URLS = (
        "stackoverflow.com",
        "google.com",
        "gmail.com",
        "youtube.com"
    )

    for url in URLS:
        print("opening: " + url)
        wb.get(chrome_path).open_new_tab(url)

webauto()