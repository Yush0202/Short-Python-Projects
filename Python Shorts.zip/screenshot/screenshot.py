import time
import pyautogui
import tkinter as tk

def screenshot():
    name = int(round(time.time() * 1000)) #create random number for file name
    name = 'C:/Users/KIIT/Desktop/Python tut/screenshot/screenshots data/{}.png'.format(name) #change format of name to .png
    #time.sleep(5) #take ss after 5 seconds
    img = pyautogui.screenshot(name)
    img.show()

root = tk.Tk()
frame = tk.Frame(root)
frame.pack()

button = tk.Button(
    frame,
    text = "Take Screenshot",
    command = screenshot
)
button.pack(side=tk.LEFT)

close =tk.Button(
    frame,
    text = "QUIT",
    command = quit
)
close.pack(side=tk.LEFT)

root.mainloop()