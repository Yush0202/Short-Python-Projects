import pyshorteners

url = input("Enter URL:\n")

print("URL after shortening: ", pyshorteners.Shortener().tinyurl.short(url))



#import pyshorteners
#
## Get the URL from the user
#url = input("Enter URL:\n")
#
## Create a Shortener object
#shortener = pyshorteners.Shortener()
#
## Shorten the URL using the TinyURL service
#shortened_url = shortener.tinyurl.short(url)
#
## Print the shortened URL
#print("URL after shortening: ", shortened_url)
