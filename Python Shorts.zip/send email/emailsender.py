import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def sendEmail(to, content):
    try:
        # Email details
        sender = "ayushatnet2024@gmail.com"
        pas = "gterghkvlofagwmx"  # Replace with your app-specific password
        
        # multipart message 
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = to
        msg['Subject'] = subject
        
        #  email body
        msg.attach(MIMEText(content, 'plain'))
        
        #secure SSL context
        context = ssl.create_default_context()
        
        # Connect to the server using SMTP_SSL for SSL encryption
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender, pas)
            server.sendmail(sender, to, msg.as_string())

        print("Email sent successfully!")

    except Exception as e:
        print(f"Failed to send email. Error: {e}")

if __name__ == "__main__":
    to = input("Enter the email of recipient:\n")
    content = input("Enter the content for mail:\n")
    subject = input("Enter the subject for the mail:\n")
    sendEmail(to, content)
