import pyttsx3

engine = pyttsx3.init()
engine.say("This is narrator tool!Paste the text to narrate!")
engine.runAndWait()
narrate = input("Paste the text to narrate:\n")
engine.say(narrate)
engine.runAndWait()